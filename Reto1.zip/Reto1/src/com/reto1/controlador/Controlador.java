package com.reto1.controlador;

import com.reto1.modelo.Modelo;
import com.reto1.vista.Vista;

import java.util.Scanner;

public class Controlador {
    private Vista view;
    private Modelo model;
    int x = 1;
    int estra;
    int cons;

    public Controlador(Vista view, Modelo model) {
        this.view = view;
        this.model = model;
        while (x == 1) {
            this.view.menu();
            Scanner entrada = new Scanner(System.in);
            int opcion = entrada.nextInt();
            switch (opcion) {
                case 1:
                    System.out.println("Pago de servicio de Energia");
                    System.out.println("Estrato del inmueble:");
                    estra = entrada.nextInt();
                    model.setEstrato(estra);
                    System.out.println("Consumo del inmueble:");
                    cons = entrada.nextInt();
                    model.setConsumo(cons);
                    model.energy();
                    break;
                case 2:
                    System.out.println("Pago de servicio de acueducto");
                    System.out.println("Estrato del inmueble:");
                    estra = entrada.nextInt();
                    model.setEstrato(estra);
                    System.out.println("Consumo del inmueble:");
                    cons = entrada.nextInt();
                    model.setConsumo(cons);
                    model.acueducto();
                    break;
                case 3:
                    System.out.println("Pago de servicio de gas natural");
                    System.out.println("Estrato del inmueble:");
                    estra = entrada.nextInt();
                    model.setEstrato(estra);
                    System.out.println("Consumo del inmueble:");
                    cons = entrada.nextInt();
                    model.setConsumo(cons);
                    model.gas();
                    break;
                case 4:
                    x = 0;
                    System.out.println("Hasta pronto");
                    break;
            }

        }
    }
}