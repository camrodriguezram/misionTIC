package com.reto1.vista;

import java.util.Scanner;

public class Vista {
    public void menu(){

        System.out.println("PAGO DE SERVICIOS PÚBLICOS");
        System.out.println("Seleccione el servicio público:");
        System.out.println("1. Energia" );
        System.out.println("2. Acueducto" );
        System.out.println("3. Gas Natural" );
        System.out.println("4. Salir" );
        System.out.println("Opción: ");
    }
}