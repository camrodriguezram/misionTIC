package com.reto1.modelo;

public class Modelo {
    private int estrato;
    private int consumo;
    private double unidad;
    private double discount;
    private double tax;
    private double precioNeto;
    private double total;

    public void descuento(){

        if (estrato <= 2 ){
            this.discount = 0.5;
        }
        else if (estrato <=4){
            this.discount = 0.1;
        }
        else{
            this.discount = -0.25;
        }

    }
    public void gas(){
        this.unidad = 5234;
        descuento();
        resultado();
        info();
    }
    public void acueducto(){
        this.unidad = 9256;
        descuento();
        resultado();
        info();
    }
    public void energy(){
        this.unidad = 6200;
        descuento();
        resultado();
        info();
    }
    public void resultado(){
        this.precioNeto = unidad*consumo;
        this.tax = precioNeto * 0.01;
        this.total = precioNeto-(precioNeto * discount)+tax;
    }
    public void info(){
        System.out.println("El consumo fue: " + this.consumo);
        System.out.println("Valor unidad: "+this.unidad);
        System.out.println("Estrato del inmueble: " + this.estrato);
        System.out.println("Costo total: "+ this.precioNeto);
        System.out.println("Descuento o sobrecosto: " +(precioNeto * discount*-1));
        System.out.println("Impuesto por infraestructura: "+this.tax);
        System.out.println("TOTAL A PAGAR: "+this.total);
        System.out.println(" " );
    }


    public int getEstrato() {
        return estrato;
    }

    public void setEstrato(int estrato) {
        this.estrato = estrato;
    }

    public int getConsumo() {
        return consumo;
    }

    public void setConsumo(int consumo) {
        this.consumo = consumo;
    }
    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }
    public double getTax() {
        return tax;
    }

    public void setTax(double tax) {
        this.tax = tax;
    }

    public double getPrecioNeto() {
        return precioNeto;
    }

    public void setPrecioNeto(double precioNeto) {
        this.precioNeto = precioNeto;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
    public double getUnidad() {
        return unidad;
    }

    public void setUnidad(double unidad) {
        this.unidad = unidad;
    }


}
