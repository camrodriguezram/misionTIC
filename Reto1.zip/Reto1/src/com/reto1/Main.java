package com.reto1;

import com.reto1.controlador.Controlador;
import com.reto1.modelo.Modelo;
import com.reto1.vista.Vista;

public class Main {

    public static void main(String[] args) {
        Modelo mod = new Modelo();
        Vista view = new Vista();
        Controlador ctrl = new Controlador(view,mod);
        }
        
    }

